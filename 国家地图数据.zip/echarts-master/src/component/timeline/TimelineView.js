import ComponentView from '../../view/Component';

export default ComponentView.extend({
    type: 'timeline'
});
