# echarts

推荐使用hb运行，因为省市json需要类似的运行环境才能读取出来，直接运行index.html 是没有数据可查的
